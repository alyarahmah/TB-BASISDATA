
<nav class="navbar bg-body-tertiary " data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand">Sistem Parkir Kerkhof Garut</a>
    <form class="d-flex" role="search">
      <input class="form-control me-2" name="keyword" type="search" placeholder="Cari Plat nomor"  autocomplete="off" aria-label="Search">
      <button class="btn btn-secondary" name="Cari" type="submit">Cari</button>
    </form>
  </div>
</nav>